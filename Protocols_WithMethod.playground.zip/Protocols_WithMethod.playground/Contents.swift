import UIKit

/*
 The following example defines a protocol with a single instance method requirement:
*/

protocol SlopeCalculator {
    func slopeCalculate() -> Double
}

class StraightLine: SlopeCalculator {
    func slopeCalculate() -> Double {
        return (y2-y1)/(x2-x1)
    }
    
    var x1: Double
    var x2: Double
    var y1: Double
    var y2: Double
    init(x1: Double, x2: Double, y1: Double, y2: Double) {
        self.x1 = x1
        self.x2 = x2
        self.y1 = y1
        self.y2 = y2
    }
    
}

let straightLine = StraightLine(x1: 1, x2: 2, y1: 2, y2: 4)
print(straightLine.slopeCalculate())
