import UIKit

/*
 
Protocols used to minimize the unnecessary codes.

It's name represent the effect applied on the conforming type.

Protocols can be injected as parameters types.

*/

protocol Printable {
    var name: String {get}
}

struct Cat: Printable {
    var name: String
}

struct Dog: Printable {
    var name: String
}

var pet1 = Dog(name: "Wolf")
var pet2 = Cat(name: "Betsy")

func printOutPetsName(object: Printable) {
    print(object.name)
}

printOutPetsName(object: pet1)
printOutPetsName(object: pet2)

