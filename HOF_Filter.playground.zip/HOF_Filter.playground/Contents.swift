import UIKit

/*
Higher order functions operate on other functions (as an argument or a return).

1. Map
2. Filter
3. Reduce
4. Flatmap
5. Sorted
 
*/

//1. Map: Tranforms the array elements. (There's a video already with file)

//2. Filter: Returns the array based upon the filter condition

// Talking points: Inline and Closure syntax with examples.

let integers : [Int] = [1, 2, 3, 4, 5]
let filteredIntegers1 = integers.filter{$0>3} //Inline Syntax
print(filteredIntegers1)
let filteredIntegers2 = integers.filter { (integer) -> Bool in
    return integer<3 && integer>1
} //Closure Syntax
print(filteredIntegers2)

let dict = ["x1": 1, "x2": 40, "x3": 45]
let dict1 = dict.filter{$0.value>10}
print(dict1)

