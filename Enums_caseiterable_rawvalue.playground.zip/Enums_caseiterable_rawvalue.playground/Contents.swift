import UIKit

/* Enum:
An enumeration defines a common type for a group of related values. For eg: direction : north south east and west. eg 2 Planets
*/

enum CompassPoint {
    case north
    case south
    case east
    case west
}

enum Planet : CaseIterable {
    case mercury, venus, earth, mars, jupiter, saturn, uranus, neptune
}

var directionToHead = CompassPoint.east
directionToHead = CompassPoint.west

switch directionToHead {
case .north:
    print("Most planets have north.")
case .south:
    print("Watch out for penguins.")
case .east:
    print("Where the sun rises.")
case .west:
    print("Sky appears blue.")
}

var somePlanet = Planet.saturn
somePlanet = .mars
somePlanet = .earth
switch somePlanet {
case .earth:
    print("This planet is safe for humans.")
case .mars:
    print("Life there is under study.")
default:
    print("Humans cannot survive on this planet.")
}

let numberOfPlanets = Planet.allCases.count

for planet in Planet.allCases {
    print("Planet name: \(planet)")
}

//Associated Values in Enum:

enum Pet {
    case cat(String, Int)
    case dog(String, Int)
    case parrot(Int)
}

let cat1 = Pet.cat("Persian", 12)
let dog1 = Pet.dog("Australian Cattle", 20)
let parrot1 = Pet.parrot(40)

let pet = dog1
switch pet {
case .cat(let breed, let age):
    print("The \(breed) cat has the age of \(age) years.")
case .dog(let breed, let age):
        print("The \(breed) dog has the age of \(age) years.")
case .parrot(let age):
    print("Average age of a parrot is \(age) years.")
default:
    ()
}

enum Alphabet: Int {
    case a, b, c, d, e, f, g, h, i, j, k = 11, l
}

let orderOfe = Alphabet.e.rawValue
let possibleAlphabet = Alphabet(rawValue: 3)
if let possibleAlphabet = Alphabet(rawValue: 0) {
    print(possibleAlphabet)
}


//Ref: swift.org

