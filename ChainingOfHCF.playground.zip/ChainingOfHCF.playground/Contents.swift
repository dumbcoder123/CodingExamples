import UIKit

/* Chaining:
 Combining multiple functions together to perform certain task at once
 */

class Student {
    var firstName = ""
    var lastName = ""
    var ageInYears = 0
}


var std1 = Student()
std1.firstName = "Sujeet"
std1.lastName = "Poudel"
std1.ageInYears = 16

var std2 = Student()
std2.firstName = "Ram"
std2.lastName = "Shrinivas"
std2.ageInYears = 18

var std3 = Student()
std3.firstName = "Raj"
std3.lastName = "Parth"
std3.ageInYears = 20

var std4 = Student()
std4.firstName = "Suman"
std4.lastName = "Dhakal"
std4.ageInYears = 22

var std5 = Student()
std5.firstName = "Raj"
std5.lastName = "Kiran"
std5.ageInYears = 24

var std6 = Student()
std6.firstName = "Kamala"
std6.lastName = "Bodhi"
std6.ageInYears = 26

var array = [[std1, std2, std3], [std4, std5, std6]]

array
    .flatMap {$0}
    .sorted { x, y in
        return x.lastName < y.lastName
    }
    .forEach { x in
    if x.firstName == "Raj" {
        print(x.lastName)
    }
}




/*
 Reference: An answer on https://stackoverflow.com/questions/31652406/how-to-iterate-through-array-of-objects-in-swift
*/
