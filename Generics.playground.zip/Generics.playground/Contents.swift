import UIKit

/*
 Generic code enables you to write flexible and reusable functions, that are common functions working for variety of data.
 */

func add<T : Numeric>(a : T, b : T) -> T {
    return a + b
}

print(add(a: 1, b: 2))
print(add(a: 1.5, b: 2.5))

func swapTwoValues<T> (_ a : inout T, _ b: inout T) {
    let temporary = a
    a = b
    b = temporary
}

var x = "ab"
var y = "cd"
print("Before swapping: \(x),\(y)")
swapTwoValues(&x, &y)
print("After swapping:  \(x),\(y)")
