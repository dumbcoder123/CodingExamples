import UIKit

/*
Higher order functions operate on other functions (as an argument or a return).

1. Map
2. Filter
3. Reduce
4. Flatmap
5. Sorted
 
*/

//1. Map: Tranforms the array elements. (There's a video already with file)

//2. Filter: Returns the array based upon the filter condition. (There's a video and the example file.)

//3. Reduce: Combines all the elements of the array and gives out a single value (There's a video already.)

//4. Flatmap: Flatmaps flattens the arrays within an array into a single array, and removes the nil

let numberArrays = [[1, 2], [4, 5]]
print(numberArrays.flatMap{$0})
let strings = ["a", nil, "b", nil, "c"]
print(strings.flatMap{$0})


