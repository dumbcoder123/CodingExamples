import UIKit

/*
A lazy stored property is a property whose initial value is not calculated until the first time it is used.
 
 Used when initialization of certain property which is computationally intense or time consuming which need not be performed unless or until it is needed.
*/

class MedicalHistory {
    var fileName = "fileName.txt"
    func loadMedicalHistory() {
        // use the fileName property here.
    }
}

class Person {
    var name: String
    lazy var medicalHistory = MedicalHistory()
    //var must be used, why? You do not know whether there will be a value before the instance initialization completes.
    init(nameOfPerson name: String) {
        self.name = name
    }
}

var john = Person(nameOfPerson: "John Doe")
john.name
john.medicalHistory.fileName

