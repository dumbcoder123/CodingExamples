import UIKit

/* Enum:
An enumeration defines a common type for a group of related values. For eg: direction : north south east and west. eg 2 Planets
*/

enum CompassPoint {
    case north
    case south
    case east
    case west
}

enum Planet {
    case mercury, venus, earth, mars, jupiter, saturn, uranus, neptune
}

var directionToHead = CompassPoint.east
directionToHead = CompassPoint.west

switch directionToHead {
case .north:
    print("Most planets have north.")
case .south:
    print("Watch out for penguins.")
case .east:
    print("Where the sun rises.")
case .west:
    print("Sky appears blue.")
}

var somePlanet = Planet.saturn
somePlanet = .mars
somePlanet = .earth
switch somePlanet {
case .earth:
    print("This planet is safe for humans.")
case .mars:
    print("Life there is under study.")
default:
    print("Humans cannot survive on this planet.")
}

//Ref: swift.org
