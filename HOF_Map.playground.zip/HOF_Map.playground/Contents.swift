import UIKit

/*
Higher order functions operate on other functions (as an argument or a return).

1. Map
2. Filter
3. Reduce
4. Flatmap
5. Sorted
 
*/

//1. Map: Tranform the array elements
let numberArray = [1, 2, 3, 4, 5]
print(numberArray.map {$0*10})
print(numberArray.map {$0-1})
print(numberArray.map {String($0)})

let stateArray = ["Texas", "Florida"]
print(stateArray.map {$0.uppercased()})
print(stateArray.map {$0.count})

let modifiedArray = stateArray.map {(state) -> String in
    return "State: \(state)"
}
print(modifiedArray)


 




























