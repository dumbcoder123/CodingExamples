import UIKit

/* Delegation: It is a design pattern that enables a class or structure to hand-off(or delegate) some of its
 responsibilities to an instance of another type.
 */

protocol namedCountry {
    init(countryName: String)
}

protocol CountryRepresenter: class {
    func performDiplomaticDecisions()
}

final class Country: namedCountry {
    var name: String
    init(countryName name: String) {
        self.name = name
    }
    
    weak var delegate : CountryRepresenter?
    
    func representCountry() {
        delegate?.performDiplomaticDecisions()
    }
    
}

class NepalRepresenter: CountryRepresenter {
    func performDiplomaticDecisions() {
        print("Charter border trade plans with China and India.")
    }
}

class USRepresenter: CountryRepresenter {
    func performDiplomaticDecisions() {
        print("Charter border trade plans with Mexico and Canada.")
    }
}

var nepal = Country(countryName: "Nepal")
var rajGurung = NepalRepresenter()
nepal.delegate = rajGurung
nepal.representCountry()

var johnDoe = USRepresenter()
var usa = Country(countryName: "USA")
usa.representCountry()
