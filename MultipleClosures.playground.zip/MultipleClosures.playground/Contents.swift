import UIKit

func findLeapYear(year: Int, onLeapYear: (Int)->(), onNotLeapYear: (Int, Int) -> ()) {
    let quotientYear = year%4
    if quotientYear == 0 {
        onLeapYear(year)
    } else {
        onNotLeapYear(year, quotientYear)
    }
}

findLeapYear(year: 2021, onLeapYear: { (year) in
    print("Congrats, \(year) is the leap year.")
}) { (year, quotientYear) in
    print("Sorry, \(year) is not a leap year; \(4-quotientYear) more years to go!")
}
