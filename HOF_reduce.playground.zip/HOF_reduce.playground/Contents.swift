import UIKit

/*
Higher order functions operate on other functions (as an argument or a return).

1. Map
2. Filter
3. Reduce
4. Flatmap
5. Sorted
 
*/

//1. Map: Tranforms the array elements. (There's a video already with file)

//2. Filter: Returns the array based upon the filter condition. (There's a video and the example file.)

//3. Reduce: Combines all the elements of the array and gives out a single value

let integerArray = [1, 2, 3, 4, 5]
print(integerArray.reduce(100, +)) //Inline syntax
let integerSum = integerArray.reduce(0) { x, y -> Int in
    return x + y
} //Closure syntax
print(integerSum)
let strings = ["s", "t", "uv"]
print(strings.reduce("", +))
//Convert the integerArray into an integer string
let integersString = integerArray.reduce("") { x, y -> String in
    return x + String(y)
}
print(integersString)
print(integerArray.reduce(""){$0 + String($1)})

