import UIKit

protocol RandomNumberGenerator {
    func random() -> Double
}

class LinearCongruentialGenerator: RandomNumberGenerator {
    var lastRandom = 42.0
    let m = 139968.0
    let a = 3877.0
    let c = 29573.0
    let k: Int
    init(k: Int) {
        self.k = k
    }
    func random() -> Double {
        lastRandom = ((lastRandom * a + c)
            .truncatingRemainder(dividingBy:m))
        return lastRandom / (m*Double(k))
    }
}

class TimeRandomGenerator: RandomNumberGenerator {
    let date = Date()
    let calendar = Calendar.current
    func random() -> Double {
        let second = calendar.component(.second, from: Date())
        return Double(second%10)/10
    }
}

class Dice {
    let sides: Int
    let generator: RandomNumberGenerator
    init(sides: Int, generator: RandomNumberGenerator) {
        self.sides = sides
        self.generator = generator
    }
    func roll() -> Int {
        return Int(generator.random()*Double(sides)) + 1
    }
}

var dice_6 = Dice(sides: 6, generator: LinearCongruentialGenerator(k: 1))
for _ in 1...5 {
    print("Random dice roll output using LCG: \(dice_6.roll())")
}
var dice_10_TRG = Dice(sides: 10, generator: TimeRandomGenerator())
print("Random dice roll output using TRG: \(dice_10_TRG.roll())")


