import UIKit

/*
 Mutating Method Requirements

 It’s sometimes necessary for a method to modify (or mutate) the instance it belongs to. For instance methods on value types (that is, structures and enumerations) you place the mutating keyword before a method’s func keyword to indicate that the method is allowed to modify the instance it belongs to and any properties of that instance.
 
 swift.org
 */

protocol Toggle {
    mutating func toggle()
}

enum OnOffSwitch: Toggle {
    case on, off
    mutating func toggle() {
        switch self {
        case .on:
            self = .off
        case .off:
            self = .on
        }
    }
}

var  lightSwitch = OnOffSwitch.off
lightSwitch.toggle()

