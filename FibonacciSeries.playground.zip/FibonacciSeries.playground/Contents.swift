import UIKit

/*
 1. Generate Fibonacci Numbers:
 0, 1, 1, 2, 3, 5, 8, 13, 21, 34 ...
 */

/*
 2. Check Palindrome:
 What is common in these word?
 redivider, deified, civic, radar, level, rotor, kayak, reviver, racecar, madam, and refer
 */

var counter = 1
var a = 0
var b = 0
var c = 1
repeat {
    print(b)
    a = b
    b = c
    c = a + b
    counter += 1
} while counter <= 50


var string = "110111"
string = string.lowercased()
if String(string.reversed()) == string {
    print("\(string) is a palindrome.")
} else {
    print("\(string) is not a palindrome.")
}
