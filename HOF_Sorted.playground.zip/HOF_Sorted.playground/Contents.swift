import UIKit

/*
Higher order functions operate on other functions (as an argument or a return).

1. Map
2. Filter
3. Reduce
4. Flatmap
5. Sorted
 
*/

//1. Map: Tranforms the array elements. (There's a video already with file)

//2. Filter: Returns the array based upon the filter condition. (There's a video and the example file.)

//3. Reduce: Combines all the elements of the array and gives out a single value (There's a video already.)

//4. Flatmap: Flatmaps flattens the arrays within an array into a single array, and removes the nil (Theres a video.)

//5. Sorted: Sorts the integers or strings array in ascending order by default.

//Talking points: i. Ascending order ii. Descending order (w/ closure) iii. Short hand iv. String

let integerArray = [1, 9, 3, 4, 7, 6, 5, 8, 2]
print(integerArray.sorted())
//let descendingArray = integerArray.sorted { x, y -> Bool in
//    print("\(x) compared with \(y) : \(x > y)")
//    return x > y
//}
let descendingArray = integerArray.sorted(by: >)
print(descendingArray)
let strings = ["x", "sd", "af", "q", "zebra"]
print(strings.sorted(by: >))
let evenFirst = integerArray.sorted { x, y -> Bool in
    return x%2 == 0
}
print(evenFirst)

