import UIKit

/*
 
 A protocol defines a 'blueprint' of methods, properties, and other requirements that suit a particular task or piece of functionality.
 
 The protocol can then be adopted by a class, structure, or enumeration to provide an actual implementation of those requirements.
 
 Any type that satisfies the requirements of a protocol is said to 'conform' to that protocol.
 
 Ref: swift.org
 
 */

protocol FullyNamed {
    var fullName: String {get}
    //A property must be either gettable or gettable and settable
}

struct Person: FullyNamed {
    var fullName: String
    //Stored or computed property, you may use either of them for gettable property
}

var john = Person(fullName: "John Doe")
john.fullName = "John Robert"
print(john.fullName)
